﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaquinaExpendedora_ProyectoFinal {
    internal class ProductosAlimenticios : Producto {

        // PROPIEDADES

        /// Propiedad pública de InformacionNutricional 
        public string InformacionNutricional { get; set; }

        // CONSTRUCTORES

        /// Contructor por defecto 
        public ProductosAlimenticios() { }

        // CONTRUCTOR PARAMETRIZADO

        /// Contructor parametrizado de Productos Alimenticios 
        public ProductosAlimenticios(int id, string nombre, int unidades, double precioUnitario, string descripcion,
            string informacionNutricional) : base(id, nombre, TipoProducto.ProductosAlimenticios, descripcion, unidades, precioUnitario) {
            InformacionNutricional = informacionNutricional;
        }

        // METODOS

        ///  Metodo público sobreescrito heredado de su padre 'Producto'
        public override void MostrarInformacion() {
            base.MostrarInformacion();
            Console.WriteLine($" Informacion nutricional: {InformacionNutricional}");
        }

    }
}
