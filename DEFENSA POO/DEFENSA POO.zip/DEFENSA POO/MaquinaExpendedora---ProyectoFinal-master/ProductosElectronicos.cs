﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaquinaExpendedora_ProyectoFinal {
    internal class ProductosElectronicos : Producto {

        // PROPIEDADES

        /// Propiedad pública de TipoMaterial 
        public string TipoMaterial {  get; set; }

        /// Propiedad pública de TieneBateria
        public bool TieneBateria { get; set; }

        /// Propiedad pública de Precargado
        public bool Precargado { get; set; }

        // CONSTRUCTORES

        /// Contructor por defecto de Productos Electronicos 
        public ProductosElectronicos() { }

        // CONTRUCTOR PARAMETRIZADO

        /// Contructor parametrizado de Productos Electronicos inicializado cada propiedad 

        public ProductosElectronicos(int id, string nombre, int unidades, double precioUnitario, string descripcion, string tipoMaterial, 
            bool tieneBateria, bool precargado) : base(id, nombre, TipoProducto.ProductosElectronicos, descripcion, unidades, precioUnitario) {
            TipoMaterial = tipoMaterial;
            TieneBateria = tieneBateria;
            Precargado = precargado;
        }

        // METODOS

        /// Método público sobreescrito de MostrarInformacion
        /// Lo tiene heredado de su padre 'Producto'
        public override void MostrarInformacion() {
            base.MostrarInformacion();
            Console.WriteLine($" Tipo Material: {TipoMaterial}");
            Console.WriteLine($" Tiene bateria: {TieneBateria}");
            Console.WriteLine($" Precargado: {(Precargado ? "Si" : "No")}");
        }
    }
}
