﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachinePropia {
    internal class Usuario {

        // PROPIEDADES

        /// Propiedad pública de un Enum TipoUsuario
        public enum TipoUsuario {
            Cliente,
            Admin
        }

        /// Propiedad público de TipoUsuario
        public TipoUsuario Tipo { get; set; }

        // CONTRUCTORES 

        /// Contructor por defecto de Usuario
        public Usuario() { }

        /// Constructor Usuario con parametro de TipoUsuario
        public Usuario(TipoUsuario tipo) {
            Tipo = tipo;
        }
    }
}
