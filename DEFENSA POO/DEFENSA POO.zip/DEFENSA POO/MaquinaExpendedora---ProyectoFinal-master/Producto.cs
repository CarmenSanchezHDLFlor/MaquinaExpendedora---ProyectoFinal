﻿using MaquinaExpendedora___ProyectoFinal;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaquinaExpendedora_ProyectoFinal {
    internal class Producto {

        // TIPO ENUM 

        /// Propiedad pública tipo Enum de TipoProducto
        /// Nos ayuda a saber que tipos de productos tenemos 
        public enum TipoProducto {
            MaterialesPreciosos,
            ProductosAlimenticios,
            ProductosElectronicos
        }

        // PROPIEDADES

        /// Propiedad pública Id de un producto 
        public int Id { get; set; }

        /// Propiedad pública Nombre de un producto 
        public string Nombre { get; set; }

        /// Propiedad pública Unidades
        /// Cuantas unidades de cada producto tenemos 
        public int Unidades { get; set; }

        /// Propiedad pública PrecioUnitario
        /// El precio de cada producto 
        public double PrecioUnitario { get; set; }

        /// Propiedad pública de Descripcion 
        /// La descripcion de cada producto que tenemos en la máquina 
        public string Descripcion { get; set; }

        /// Propiedad pública de Vendido
        /// Nos ayuda a comprobar si un producto ha sido vendido, no tenemos stock o no 
        public bool Vendido {  get; set; }

        /// Propiedad pública de TipoProducto 
        public TipoProducto Tipo;

        // CONTRUCTORES 

        /// Contructor por defecto de Producto 
        public Producto() { }

        // CONTRUCTOR PARAMETRIZADO
        /// Constructor parametrizado de Producto 
        /// Inicializa las propiedades de Producto
        public Producto(int id, string nombre, TipoProducto tipo, string descripcion, int unidades, double precioUnitario) {
            Id = id;
            Nombre = nombre;
            Tipo = tipo;
            Descripcion = descripcion;
            Unidades = unidades;
            PrecioUnitario = precioUnitario;
        }

        // METODOS

        /// Método público para mostrar informacion de cada producto
        /// Este método es el que se va a sobreescribir en sus hijas 'ProductosElectronico', 'ProductosAlimenticios' y 'MaterialesPreciosos'
        /// Nos da la información común de cada producto 
        public virtual void MostrarInformacion() {
            Console.WriteLine($" Nombre: {Nombre}");
            Console.WriteLine($" Unidades: {Unidades}");
            Console.WriteLine($" Precio Unitario: {PrecioUnitario}");
            Console.WriteLine($" Descripcion: {Descripcion}");
        }

        /// Método público para consultar si el producto está vendido
        public bool EstaVendido() {
            return Vendido;
        }

        /// Método público para marcar el producto como vendido
        public void MarcarComoVendido() {
            Vendido = true;
        }
    }
}
