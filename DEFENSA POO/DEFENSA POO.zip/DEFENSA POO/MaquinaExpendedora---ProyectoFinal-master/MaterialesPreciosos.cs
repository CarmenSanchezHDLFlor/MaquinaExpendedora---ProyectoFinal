﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaquinaExpendedora_ProyectoFinal {
    internal class MaterialesPreciosos : Producto {

        // PROPIEDADES

        /// Propiedad pública de TipoMaterial 
        public string TipoMaterial {  get; set; }

        /// Propiedad pública de Peso
        public double Peso { get; set; }

        // CONSTRUCTORES

        /// Constructor por defecto de MaterialesPreciosos
        public MaterialesPreciosos() { }

        // CONTRUCTOR PARAMETRIZADO

        /// Constructor parametrizado inicializando las propiedades de la clase 
        /// Y heredando las de su padre 'Producto'

        public MaterialesPreciosos(int id, string nombre, int unidades, double precioUnitario, string descripcion,
            string tipoMaterial, double peso)
            : base(id, nombre, TipoProducto.MaterialesPreciosos, descripcion, unidades, precioUnitario) {
            TipoMaterial = tipoMaterial;
            Peso = peso;
        }

        // METODOS

        /// Método público sobreescrito para mostrar la info de materiales preciosos
        /// Hereda la informacion de su padre 'Producto'
        public override void MostrarInformacion() {
            base.MostrarInformacion();
            Console.WriteLine($" TipoMaterial: {TipoMaterial}");
            Console.WriteLine($" Peso: {Peso} gramos");
        }

    }
}
